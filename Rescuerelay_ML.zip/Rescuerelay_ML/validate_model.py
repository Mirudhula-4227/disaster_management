import pandas as pd
import joblib

from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)

# ==========================================
# 1. LOAD TRAINED MODEL
# ==========================================

model = joblib.load("models/severity_model.joblib")

print("Trained model loaded successfully!")


# ==========================================
# 2. LOAD VALIDATION DATASET
# ==========================================

data = pd.read_csv("data/sos_validation_50.csv")

print("Validation dataset loaded successfully!")
print("Number of validation reports:", len(data))


# ==========================================
# 3. DEFINE FEATURES AND TARGET
# ==========================================

features = [
    "description",
    "category",
    "people_affected",
    "vulnerable_people",
    "situation",
    "assistance"
]

X = data[features]
y_actual = data["severity_label"]


# ==========================================
# 4. MAKE PREDICTIONS
# ==========================================

predictions = model.predict(X)

probabilities = model.predict_proba(X)

confidences = probabilities.max(axis=1)


# ==========================================
# 5. DISPLAY EACH REPORT
# ==========================================

print("\n==========================================")
print("VALIDATION REPORT RESULTS")
print("==========================================")

for i in range(len(data)):

    print("\n------------------------------------------")
    print("REPORT", i + 1)
    print("------------------------------------------")

    print("Description:", data.iloc[i]["description"])

    print("Expected severity:", y_actual.iloc[i])

    print("ML prediction:", predictions[i])

    print(
        "ML confidence:",
        round(confidences[i] * 100, 2),
        "%"
    )

    if predictions[i] == y_actual.iloc[i]:
        print("Result: CORRECT")
    else:
        print("Result: INCORRECT")


# ==========================================
# 6. OVERALL PERFORMANCE
# ==========================================

accuracy = accuracy_score(
    y_actual,
    predictions
)

print("\n\n==========================================")
print("VALIDATION PERFORMANCE")
print("==========================================")

print(
    "Accuracy:",
    round(accuracy * 100, 2),
    "%"
)


# ==========================================
# 7. CLASSIFICATION REPORT
# ==========================================

print("\nClassification Report:")

print(
    classification_report(
        y_actual,
        predictions,
        labels=["critical", "high", "normal"]
    )
)


# ==========================================
# 8. CONFUSION MATRIX
# ==========================================

print("\nConfusion Matrix:")

matrix = confusion_matrix(
    y_actual,
    predictions,
    labels=["critical", "high", "normal"]
)

print(matrix)

print("\nMatrix order:")
print("[Critical, High, Normal]")


# ==========================================
# 9. CRITICAL RECALL
# ==========================================

report = classification_report(
    y_actual,
    predictions,
    labels=["critical", "high", "normal"],
    output_dict=True
)

critical_recall = report["critical"]["recall"]

print(
    "\nCritical Recall:",
    round(critical_recall * 100, 2),
    "%"
)


# ==========================================
# 10. HIGH RECALL
# ==========================================

high_recall = report["high"]["recall"]

print(
    "High Recall:",
    round(high_recall * 100, 2),
    "%"
)


# ==========================================
# 11. NORMAL RECALL
# ==========================================

normal_recall = report["normal"]["recall"]

print(
    "Normal Recall:",
    round(normal_recall * 100, 2),
    "%"
)


print("\n==========================================")
print("VALIDATION COMPLETED")
print("==========================================")