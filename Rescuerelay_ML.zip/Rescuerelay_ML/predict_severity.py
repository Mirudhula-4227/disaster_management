import pandas as pd
import joblib


# ==========================================
# 1. LOAD THE TRAINED MODEL
# ==========================================

model = joblib.load("models/severity_model.joblib")


# ==========================================
# 2. CREATE A NEW SOS REPORT
# ==========================================

report = pd.DataFrame([{
    "description": "Two people are trapped in a flooded vehicle and water is rising rapidly",
    "category": "flood",
    "people_affected": 2,
    "vulnerable_people": 0,
    "situation": "escalating",
    "assistance": "rescue"
}])

# Severity selected by the user in the SOS form
user_selected_severity = "normal"


# ==========================================
# 3. ML PREDICTION
# ==========================================

ml_severity = model.predict(report)[0]

probabilities = model.predict_proba(report)[0]

confidence = max(probabilities)

print("ML predicted severity:", ml_severity)
print("ML confidence:", round(confidence * 100, 2), "%")


# ==========================================
# 4. SAFETY RULES
# ==========================================

# Combine description and assistance text
text = (
    report["description"].iloc[0] + " " +
    report["assistance"].iloc[0]
).lower()


# Hard emergency indicators
hard_emergency_words = [
    "unconscious",
    "trapped",
    "drowning",
    "severe bleeding",
    "cannot breathe",
    "not breathing"
]


# Check whether any hard emergency indicator exists
hard_emergency_detected = any(
    word in text for word in hard_emergency_words
)


# ==========================================
# 5. DETERMINE FINAL SEVERITY
# ==========================================

# Severity ranking
severity_rank = {
    "normal": 1,
    "high": 2,
    "critical": 3
}


# Take whichever severity is higher:
# user-selected OR ML prediction
final_severity = max(
    user_selected_severity,
    ml_severity,
    key=lambda x: severity_rank[x]
)


# Hard emergency ALWAYS forces Critical
if hard_emergency_detected:
    final_severity = "critical"


print("\nUser-selected severity:", user_selected_severity)
print("Hard emergency detected:", hard_emergency_detected)
print("Final severity:", final_severity)


# ==========================================
# 6. CALCULATE RELAY PRIORITY SCORE
# ==========================================

severity_score = {
    "critical": 100,
    "high": 60,
    "normal": 20
}


# Start with severity score
priority_score = severity_score[final_severity]


# Add points based on people affected
priority_score += report["people_affected"].iloc[0] * 2


# Add points for vulnerable people
priority_score += report["vulnerable_people"].iloc[0] * 5


# Add points if situation is escalating
if report["situation"].iloc[0].lower() == "escalating":
    priority_score += 20


# Add a small bonus for high-confidence ML prediction
if confidence >= 0.80:
    priority_score += 10


print("\nFinal relay priority score:", priority_score)