import pandas as pd
import joblib
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score


# ==========================================
# 1. LOAD TRAINED MODEL
# ==========================================

model = joblib.load("models/severity_model.joblib")

print("Trained model loaded successfully!")


# ==========================================
# 2. NEW UNSEEN SOS REPORTS
# ==========================================

new_reports = [

    {
        "description": "An elderly resident was found unconscious after part of an apartment collapsed",
        "category": "medical",
        "people_affected": 1,
        "vulnerable_people": 1,
        "situation": "escalating",
        "assistance": "medical rescue",
        "expected_severity": "critical"
    },

    {
        "description": "Several families are stranded on the upper floor while floodwater continues to rise",
        "category": "flood",
        "people_affected": 12,
        "vulnerable_people": 4,
        "situation": "escalating",
        "assistance": "rescue",
        "expected_severity": "critical"
    },

    {
        "description": "A person has been injured and cannot move after falling debris struck them",
        "category": "earthquake",
        "people_affected": 1,
        "vulnerable_people": 0,
        "situation": "ongoing",
        "assistance": "medical rescue",
        "expected_severity": "critical"
    },

    {
        "description": "A community shelter has run out of clean water for residents",
        "category": "supplies",
        "people_affected": 80,
        "vulnerable_people": 15,
        "situation": "ongoing",
        "assistance": "water supplies",
        "expected_severity": "high"
    },

    {
        "description": "Flames are spreading through a warehouse that has been confirmed empty",
        "category": "fire",
        "people_affected": 0,
        "vulnerable_people": 0,
        "situation": "escalating",
        "assistance": "fire control",
        "expected_severity": "high"
    },

    {
        "description": "Water has collected inside an unoccupied shop after heavy rain",
        "category": "flood",
        "people_affected": 0,
        "vulnerable_people": 0,
        "situation": "contained",
        "assistance": "property assessment",
        "expected_severity": "normal"
    },

    {
        "description": "A school building has developed small cracks following an earthquake",
        "category": "earthquake",
        "people_affected": 0,
        "vulnerable_people": 0,
        "situation": "contained",
        "assistance": "safety inspection",
        "expected_severity": "normal"
    },

    {
        "description": "An evacuation route is blocked by a large fallen tree, preventing ambulances from reaching the affected area",
        "category": "storm",
        "people_affected": 20,
        "vulnerable_people": 3,
        "situation": "ongoing",
        "assistance": "road clearance",
        "expected_severity": "high"
    },

    {
        "description": "A relief center requires extra blankets and clothing for displaced residents",
        "category": "supplies",
        "people_affected": 40,
        "vulnerable_people": 8,
        "situation": "ongoing",
        "assistance": "blankets",
        "expected_severity": "normal"
    },

    {
        "description": "Water levels have risen slightly along a road but there are no residents in danger",
        "category": "flood",
        "people_affected": 0,
        "vulnerable_people": 0,
        "situation": "contained",
        "assistance": "situation update",
        "expected_severity": "normal"
    },

    {
        "description": "A child is unable to breathe following smoke exposure inside a damaged house",
        "category": "fire",
        "people_affected": 1,
        "vulnerable_people": 1,
        "situation": "escalating",
        "assistance": "medical rescue",
        "expected_severity": "critical"
    },

    {
        "description": "A bridge has become unsafe and vehicles are being diverted to another route",
        "category": "landslide",
        "people_affected": 30,
        "vulnerable_people": 2,
        "situation": "ongoing",
        "assistance": "road clearance",
        "expected_severity": "high"
    },

    {
        "description": "A family has moved to a shelter and needs basic food supplies",
        "category": "supplies",
        "people_affected": 6,
        "vulnerable_people": 1,
        "situation": "ongoing",
        "assistance": "food supplies",
        "expected_severity": "normal"
    },

    {
        "description": "A damaged electrical pole is leaning toward a residential street",
        "category": "storm",
        "people_affected": 15,
        "vulnerable_people": 2,
        "situation": "escalating",
        "assistance": "hazard removal",
        "expected_severity": "high"
    },

    {
        "description": "A flooded basement is being monitored and everyone has already left the building",
        "category": "flood",
        "people_affected": 0,
        "vulnerable_people": 0,
        "situation": "contained",
        "assistance": "property assessment",
        "expected_severity": "normal"
    },

    {
        "description": "Two injured people are waiting for an ambulance near a collapsed wall",
        "category": "medical",
        "people_affected": 2,
        "vulnerable_people": 0,
        "situation": "ongoing",
        "assistance": "medical rescue",
        "expected_severity": "critical"
    },

    {
        "description": "A temporary camp needs additional cooking equipment for displaced families",
        "category": "supplies",
        "people_affected": 35,
        "vulnerable_people": 6,
        "situation": "ongoing",
        "assistance": "supplies",
        "expected_severity": "normal"
    },

    {
        "description": "A small fire has been extinguished and firefighters confirmed that the structure is empty",
        "category": "fire",
        "people_affected": 0,
        "vulnerable_people": 0,
        "situation": "contained",
        "assistance": "safety inspection",
        "expected_severity": "normal"
    },

    {
        "description": "People are unable to cross the flooded street because the water is getting deeper",
        "category": "flood",
        "people_affected": 7,
        "vulnerable_people": 2,
        "situation": "escalating",
        "assistance": "evacuation",
        "expected_severity": "high"
    },

    {
        "description": "A damaged building is closed for inspection and no one is currently inside",
        "category": "earthquake",
        "people_affected": 0,
        "vulnerable_people": 0,
        "situation": "contained",
        "assistance": "safety inspection",
        "expected_severity": "normal"
    }
]


# ==========================================
# 3. PREDICT NEW REPORTS
# ==========================================

predicted_severities = []
expected_severities = []


print("\n==========================================")
print("UNSEEN REPORT EVALUATION")
print("==========================================")


for i, item in enumerate(new_reports, start=1):

    report = pd.DataFrame([{
        "description": item["description"],
        "category": item["category"],
        "people_affected": item["people_affected"],
        "vulnerable_people": item["vulnerable_people"],
        "situation": item["situation"],
        "assistance": item["assistance"]
    }])

    prediction = model.predict(report)[0]

    probabilities = model.predict_proba(report)[0]

    confidence = max(probabilities)

    predicted_severities.append(prediction)
    expected_severities.append(item["expected_severity"])


    print("\n------------------------------------------")
    print("REPORT", i)
    print("------------------------------------------")

    print("Description:", item["description"])

    print("Expected severity:", item["expected_severity"])

    print("ML prediction:", prediction)

    print(
        "ML confidence:",
        round(confidence * 100, 2),
        "%"
    )

    if prediction == item["expected_severity"]:
        print("Result: CORRECT")
    else:
        print("Result: INCORRECT")


# ==========================================
# 4. OVERALL PERFORMANCE
# ==========================================

accuracy = accuracy_score(
    expected_severities,
    predicted_severities
)

print("\n\n==========================================")
print("UNSEEN REPORT PERFORMANCE")
print("==========================================")

print(
    "Accuracy:",
    round(accuracy * 100, 2),
    "%"
)


# ==========================================
# 5. CLASSIFICATION REPORT
# ==========================================

print("\nClassification Report:")

print(
    classification_report(
        expected_severities,
        predicted_severities,
        labels=["critical", "high", "normal"],
        zero_division=0
    )
)


# ==========================================
# 6. CONFUSION MATRIX
# ==========================================

matrix = confusion_matrix(
    expected_severities,
    predicted_severities,
    labels=["critical", "high", "normal"]
)

print("\nConfusion Matrix:")

print(matrix)

print("\nMatrix order:")
print("[Critical, High, Normal]")


# ==========================================
# 7. CRITICAL RECALL
# ==========================================

report = classification_report(
    expected_severities,
    predicted_severities,
    labels=["critical", "high", "normal"],
    output_dict=True,
    zero_division=0
)

critical_recall = report["critical"]["recall"]

print(
    "\nCritical Recall:",
    round(critical_recall * 100, 2),
    "%"
)


print("\n==========================================")
print("EVALUATION COMPLETED")
print("==========================================")

