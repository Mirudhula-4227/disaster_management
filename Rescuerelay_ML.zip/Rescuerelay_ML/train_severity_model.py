import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    accuracy_score,
    recall_score
)


# ==========================================
# 1. LOAD THE DATASET
# ==========================================

data = pd.read_csv("data/sos_training_200.csv")

print("Dataset loaded successfully!")
print("Number of reports:", len(data))

print("\nColumns:")
print(data.columns.tolist())

print("\nFirst 5 reports:")
print(data.head())


# ==========================================
# 2. DEFINE FEATURES AND TARGET
# ==========================================

features = [
    "description",
    "category",
    "people_affected",
    "vulnerable_people",
    "situation",
    "assistance"
]

target = "severity_label"

X = data[features]
y = data[target]

print("\nFeatures (X):")
print(X.head())

print("\nTarget (y):")
print(y.head())


# ==========================================
# 3. SPLIT INTO TRAINING AND TESTING DATA
# ==========================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

print("\nTraining reports:", len(X_train))
print("Testing reports:", len(X_test))

print("\nTraining label distribution:")
print(y_train.value_counts())

print("\nTesting label distribution:")
print(y_test.value_counts())


# ==========================================
# 4. PREPROCESS THE FEATURES
# ==========================================

preprocessor = ColumnTransformer(
    transformers=[

        (
            "description",
            TfidfVectorizer(
                ngram_range=(1, 2),
                min_df=1
            ),
            "description"
        ),

        (
            "category",
            OneHotEncoder(
                handle_unknown="ignore"
            ),
            ["category"]
        ),

        (
            "assistance",
            TfidfVectorizer(
                ngram_range=(1, 2)
            ),
            "assistance"
        ),

        (
            "situation",
            OneHotEncoder(
                handle_unknown="ignore"
            ),
            ["situation"]
        ),

        (
            "people",
            StandardScaler(),
            ["people_affected"]
        ),

        (
            "vulnerable",
            StandardScaler(),
            ["vulnerable_people"]
        )
    ]
)

print("\nPreprocessor created successfully!")


# ==========================================
# 5. CREATE THE ML PIPELINE
# ==========================================

model = Pipeline([
    (
        "preprocessor",
        preprocessor
    ),

    (
        "classifier",
        LogisticRegression(
            max_iter=2000,
            class_weight="balanced"
        )
    )
])

print("\nML pipeline created successfully!")


# ==========================================
# 6. TRAIN THE ML MODEL
# ==========================================

print("\nTraining the model...")

model.fit(X_train, y_train)

print("Model training completed successfully!")


# ==========================================
# 7. TEST THE MODEL
# ==========================================

print("\nTesting the model...")

predictions = model.predict(X_test)

print("\nPredicted severities:")
print(predictions)

print("\nActual severities:")
print(y_test.values)


# ==========================================
# 8. MODEL ACCURACY
# ==========================================

accuracy = accuracy_score(
    y_test,
    predictions
)

print("\n==========================================")
print("MODEL PERFORMANCE")
print("==========================================")

print(
    "Overall Accuracy:",
    round(accuracy * 100, 2),
    "%"
)


# ==========================================
# 9. CLASSIFICATION REPORT
# ==========================================

print("\nClassification Report:")

print(
    classification_report(
        y_test,
        predictions,
        labels=["critical", "high", "normal"],
        target_names=["Critical", "High", "Normal"]
    )
)


# ==========================================
# 10. CRITICAL RECALL
# ==========================================

critical_recall = recall_score(
    y_test,
    predictions,
    labels=["critical"],
    average="macro"
)

print(
    "Critical Recall:",
    round(critical_recall * 100, 2),
    "%"
)


# ==========================================
# 11. CONFUSION MATRIX
# ==========================================

matrix = confusion_matrix(
    y_test,
    predictions,
    labels=["critical", "high", "normal"]
)

print("\nConfusion Matrix:")

print(matrix)

print("\nMatrix order:")
print("[Critical, High, Normal]")


# ==========================================
# 12. SAVE THE TRAINED MODEL
# ==========================================

joblib.dump(
    model,
    "models/severity_model.joblib"
)

print("\nModel saved successfully!")

print(
    "Saved as: models/severity_model.joblib"
)