from flask import Flask, request, jsonify
import pandas as pd
import joblib

# ==========================================
# 1. CREATE FLASK APP
# ==========================================

app = Flask(__name__)


# ==========================================
# 2. LOAD TRAINED ML MODEL
# ==========================================

model = joblib.load("models/severity_model.joblib")

print("ML severity model loaded successfully!")


# ==========================================
# 3. SEVERITY SCORES
# ==========================================

severity_scores = {
    "normal": 10,
    "high": 50,
    "critical": 100
}


# ==========================================
# 4. HARD EMERGENCY KEYWORDS
# ==========================================

hard_emergency_words = [
    "unconscious",
    "trapped",
    "drowning",
    "unable to breathe",
    "not breathing",
    "severe bleeding",
    "critical injury",
    "life threatening"
]


# ==========================================
# 5. SCORE REPORT API
# ==========================================

@app.route("/score-report", methods=["POST"])
def score_report():

    data = request.get_json()

    # --------------------------------------
    # Get report information
    # --------------------------------------

    description = data.get("description", "")
    category = data.get("category", "unknown")
    people_affected = data.get("people_affected", 0)
    vulnerable_people = data.get("vulnerable_people", 0)
    situation = data.get("situation", "ongoing")
    assistance = data.get("assistance", "other")
    user_severity = data.get("user_selected_severity", "normal")


    # --------------------------------------
    # Create dataframe for ML model
    # --------------------------------------

    report = pd.DataFrame([{
        "description": description,
        "category": category,
        "people_affected": people_affected,
        "vulnerable_people": vulnerable_people,
        "situation": situation,
        "assistance": assistance
    }])


    # --------------------------------------
    # ML prediction
    # --------------------------------------

    ml_prediction = model.predict(report)[0]

    probabilities = model.predict_proba(report)[0]

    ml_confidence = max(probabilities)


    # --------------------------------------
    # HARD EMERGENCY CHECK
    # --------------------------------------

    description_lower = description.lower()

    hard_emergency_detected = any(
        word in description_lower
        for word in hard_emergency_words
    )


    # --------------------------------------
    # FINAL SEVERITY
    # --------------------------------------

    if hard_emergency_detected:

        final_severity = "critical"

    else:

        severity_order = {
            "normal": 1,
            "high": 2,
            "critical": 3
        }

        final_severity = max(
            user_severity,
            ml_prediction,
            key=lambda x: severity_order.get(x, 1)
        )


    # --------------------------------------
    # REVIEW FLAG
    # --------------------------------------

    if ml_confidence < 0.60:

        review_required = True
        review_reason = "Low ML confidence"

    elif ml_confidence < 0.80:

        review_required = True
        review_reason = "Moderate ML confidence"

    else:

        review_required = False
        review_reason = "High ML confidence"


    # --------------------------------------
    # PRIORITY SCORE
    # --------------------------------------

    severity_score = severity_scores[final_severity]

    people_score = min(people_affected * 2, 500)

    vulnerable_score = min(vulnerable_people * 5, 100)

    escalation_score = 30 if situation == "escalating" else 0

    confidence_bonus = round(ml_confidence * 20)

    priority_score = (
        severity_score
        + people_score
        + vulnerable_score
        + escalation_score
        + confidence_bonus
    )


    # ======================================
    # RETURN RESULT
    # ======================================

    return jsonify({

        "ml_prediction": ml_prediction,

        "ml_confidence": round(
            ml_confidence * 100,
            2
        ),

        "hard_emergency_detected":
            hard_emergency_detected,

        "final_severity":
            final_severity,

        "severity_score":
            severity_score,

        "priority_score":
            priority_score,

        "review_required":
            review_required,

        "review_reason":
            review_reason
    })


# ==========================================
# 6. START SERVER
# ==========================================

if __name__ == "__main__":

    app.run(
        debug=True,
        port=5000
    )