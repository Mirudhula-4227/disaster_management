import pandas as pd
import joblib


# ==========================================
# 1. LOAD THE TRAINED MODEL
# ==========================================

model = joblib.load("models/severity_model.joblib")


# ==========================================
# 2. CREATE TEST SOS REPORTS
# ==========================================

test_reports = [
    {
        "description": "Person is unconscious after a building collapse",
        "category": "medical",
        "people_affected": 1,
        "vulnerable_people": 0,
        "situation": "escalating",
        "assistance": "medical rescue",
        "user_selected_severity": "normal"
    },
    {
        "description": "Five people are trapped inside a house because floodwater is rising rapidly",
        "category": "flood",
        "people_affected": 5,
        "vulnerable_people": 2,
        "situation": "escalating",
        "assistance": "rescue",
        "user_selected_severity": "normal"
    },
    {
        "description": "Person is drowning near the river after heavy flooding",
        "category": "flood",
        "people_affected": 1,
        "vulnerable_people": 0,
        "situation": "escalating",
        "assistance": "water rescue",
        "user_selected_severity": "normal"
    },
    {
        "description": "100 people at a temporary shelter need drinking water",
        "category": "supplies",
        "people_affected": 100,
        "vulnerable_people": 20,
        "situation": "ongoing",
        "assistance": "water supplies",
        "user_selected_severity": "normal"
    },
    {
        "description": "Fire has started inside an empty abandoned building",
        "category": "fire",
        "people_affected": 0,
        "vulnerable_people": 0,
        "situation": "ongoing",
        "assistance": "fire control",
        "user_selected_severity": "normal"
    },
    {
        "description": "Floodwater has entered an empty house but nobody is inside",
        "category": "flood",
        "people_affected": 0,
        "vulnerable_people": 0,
        "situation": "ongoing",
        "assistance": "property assessment",
        "user_selected_severity": "normal"
    },
    {
        "description": "Minor cracks are visible on the wall of a building",
        "category": "earthquake",
        "people_affected": 0,
        "vulnerable_people": 0,
        "situation": "contained",
        "assistance": "safety inspection",
        "user_selected_severity": "normal"
    },
    {
        "description": "A shelter needs additional blankets for families",
        "category": "supplies",
        "people_affected": 30,
        "vulnerable_people": 5,
        "situation": "ongoing",
        "assistance": "blankets",
        "user_selected_severity": "normal"
    },
    {
        "description": "A road is blocked by fallen trees and emergency vehicles cannot pass",
        "category": "storm",
        "people_affected": 50,
        "vulnerable_people": 5,
        "situation": "ongoing",
        "assistance": "road clearance",
        "user_selected_severity": "normal"
    },
    {
        "description": "Minor flooding reported on a road with no people trapped",
        "category": "flood",
        "people_affected": 5,
        "vulnerable_people": 0,
        "situation": "ongoing",
        "assistance": "situation update",
        "user_selected_severity": "critical"
    }
]


# ==========================================
# 3. SEVERITY RANKING
# ==========================================

severity_rank = {
    "normal": 1,
    "high": 2,
    "critical": 3
}


# ==========================================
# 4. SEVERITY BASE SCORES
# ==========================================

severity_score = {
    "normal": 100,
    "high": 500,
    "critical": 1000
}


# ==========================================
# 5. HARD EMERGENCY INDICATORS
# ==========================================

hard_emergency_words = [
    "unconscious",
    "trapped",
    "drowning",
    "severe bleeding",
    "cannot breathe",
    "not breathing"
]


# ==========================================
# 6. NEGATIVE PHRASES
# ==========================================

negative_phrases = [
    "no people trapped",
    "nobody trapped",
    "no one trapped",
    "nobody is trapped",
    "no people are trapped",
    "no one is trapped"
]


# ==========================================
# 7. TEST EACH REPORT
# ==========================================

for i, item in enumerate(test_reports, start=1):

    # --------------------------------------
    # Create DataFrame for ML
    # --------------------------------------

    report = pd.DataFrame([{
        "description": item["description"],
        "category": item["category"],
        "people_affected": item["people_affected"],
        "vulnerable_people": item["vulnerable_people"],
        "situation": item["situation"],
        "assistance": item["assistance"]
    }])


    # --------------------------------------
    # ML PREDICTION
    # --------------------------------------

    ml_severity = model.predict(report)[0]

    probabilities = model.predict_proba(report)[0]

    confidence = max(probabilities)


    # --------------------------------------
    # SAFETY RULES
    # --------------------------------------

    text = (
        item["description"] + " " +
        item["assistance"]
    ).lower()


    negative_emergency = any(
        phrase in text
        for phrase in negative_phrases
    )


    hard_emergency_detected = (
        any(
            word in text
            for word in hard_emergency_words
        )
        and not negative_emergency
    )


    # --------------------------------------
    # FINAL SEVERITY
    # --------------------------------------

    user_selected_severity = item["user_selected_severity"]

    final_severity = max(
        user_selected_severity,
        ml_severity,
        key=lambda x: severity_rank[x]
    )


    # Hard emergency always becomes Critical
    if hard_emergency_detected:
        final_severity = "critical"


    # --------------------------------------
    # CONFIDENCE / REVIEW FLAG
    # --------------------------------------

    if confidence < 0.50:
        review_required = True
        review_reason = "Low ML confidence"

    elif confidence < 0.80:
        review_required = True
        review_reason = "Moderate ML confidence"

    else:
        review_required = False
        review_reason = "High ML confidence"


    # --------------------------------------
    # PRIORITY SCORE
    # --------------------------------------

    priority_score = severity_score[final_severity]

    # People affected
    priority_score += item["people_affected"] * 2

    # Vulnerable people
    priority_score += item["vulnerable_people"] * 5

    # Escalating situation
    if item["situation"].lower() == "escalating":
        priority_score += 50

    # High-confidence ML bonus
    if confidence >= 0.80:
        priority_score += 10


    # --------------------------------------
    # DISPLAY RESULTS
    # --------------------------------------

    print("\n==========================================")
    print("TEST REPORT", i)
    print("==========================================")

    print("Description:", item["description"])

    print("ML prediction:", ml_severity)

    print(
        "ML confidence:",
        round(confidence * 100, 2),
        "%"
    )

    print(
        "User-selected severity:",
        user_selected_severity
    )

    print(
        "Hard emergency detected:",
        hard_emergency_detected
    )

    print(
        "FINAL SEVERITY:",
        final_severity
    )

    print(
        "Priority score:",
        priority_score
    )

    print(
        "Review required:",
        review_required
    )

    print(
        "Review reason:",
        review_reason
    )